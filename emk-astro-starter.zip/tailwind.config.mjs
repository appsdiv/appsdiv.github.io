/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,md,mdx}'],
  theme: {
    extend: {
      colors: { brand:'#0ea5e9', ink:'#0f172a' },
      boxShadow: {
        soft:'0 10px 24px rgba(2,6,23,.06)',
        card:'0 24px 60px rgba(2,6,23,.12)',
        glow:'0 10px 50px rgba(14,165,233,.20)'
      },
      fontFamily: { sans: ['Vazirmatn','-apple-system','SF Pro Text','Inter','system-ui','Segoe UI','Roboto','Helvetica Neue','Arial','sans-serif'] }
    }
  }
}
