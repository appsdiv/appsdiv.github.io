# EMK Astro Starter (SEO-first, i18n routes, API-ready)

**Goals**: Excellent SEO (SSG), minimal changes from existing HTML/JS, easy future API hookup, and language routes with **independent** content (`/fa`, `/en`, `/tr`, `/ar`).

## Quick Start
```bash
npm i
npm run dev
```

## Structure
- `src/pages/[lang]/` — locale-scoped routes (e.g., `/fa/`, `/tr/products/`)
- `src/data/<lang>/` — locale-specific JSON for products/categories/contacts (temporary until APIs)
- `src/content/post/` — blog posts via Content Collections (`lang` frontmatter field)
- `src/components/Seo.astro` — canonical, OG/Twitter, hreflang
- `src/layouts/BaseLayout.astro` — global head, font, theme
- `src/utils/i18n.js` — lang helpers

## API Hook (Later)
Set private env `API_BASE` and pages will **server-fetch** content at build/SSR time:
```bash
# .env
API_BASE=https://api.example.com
```
- Example expected endpoints: `/{lang}/products`, `/{lang}/categories`, `/{lang}/contacts`.
- Until API is ready, JSON in `src/data/<lang>/` is used.

## SEO
- Static HTML for products/categories/blog, ready to crawl
- `<link rel="alternate" hreflang>` generated per supported lang
- `@astrojs/sitemap` + `robots.txt`
- JSON-LD Organization in `<head>`
