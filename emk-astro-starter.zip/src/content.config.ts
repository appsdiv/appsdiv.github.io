import { defineCollection, z } from 'astro:content';
const post = defineCollection({
  type: 'content',
  schema: z.object({
    title: z.string(),
    summary: z.string().optional(),
    cover: z.string().optional(),
    date: z.string(),
    lang: z.enum(['fa','en','tr','ar']),
    category: z.string().optional()
  })
});
export const collections = { post };
