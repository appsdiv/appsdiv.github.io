export const SUPPORTED_LANGS = ['fa','en','tr','ar'];
export function langInfo(lang){
  switch(lang){
    case 'fa': return { dir:'rtl', label:'FA', name:'فارسی' };
    case 'ar': return { dir:'rtl', label:'AR', name:'العربية' };
    case 'tr': return { dir:'ltr', label:'TR', name:'Türkçe' };
    case 'en': default: return { dir:'ltr', label:'EN', name:'English' };
  }
}
export function stripLang(pathname){
  return pathname.replace(/^\/(fa|en|tr|ar)(\/|$)/,'/');
}
