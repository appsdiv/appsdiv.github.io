import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';
import sitemap from '@astrojs/sitemap';
import mdx from '@astrojs/mdx';

// Languages you'll support
const LANGS = ['fa','en','tr','ar'];

export default defineConfig({
  site: 'https://example.com',
  integrations: [
    tailwind({ applyBaseStyles: true }),
    sitemap(),
    mdx()
  ],
  vite: {
    define: {
      __LANGS__: JSON.stringify(LANGS)
    }
  }
});
